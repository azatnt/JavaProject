package MainClasses;

import java.io.Serializable;

public class Computer extends Device implements Serializable {
    private boolean ssd;
    private int memory;
    private double performancee = 0;
    private double income;

    public Computer(){
    }

    public Computer(String cpu, int ram, boolean ssd, int memory) {
        super(cpu, ram);
        this.ssd = ssd;
        this.memory = memory;
    }

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public Computer(double price, String model, int count, int sold, String cpu, int ram, boolean ssd, int memory) {
        super(price, model, count, sold, cpu, ram);
        this.ssd = ssd;
        this.memory = memory;
    }

    public Computer(double price, String model, int count, String cpu, int ram, boolean ssd, int memory) {
        super(price, model, count, cpu, ram);
        this.ssd = ssd;
        this.memory = memory;
    }
    public Computer(double price, String model, int count, String cpu, int ram, boolean ssd, int memory, int sold, double income){
        super(price, model, count, sold, cpu, ram);
        this.ssd = ssd;
        this.memory = memory;
        this.income = income;
    }
    public Computer(double price, String model, int count, String cpu, int ram, boolean ssd, int memory, double performancee) {
        super(price, model, count, cpu, ram);
        this.ssd = ssd;
        this.memory = memory;
        this.performancee = performancee;
    }

    public boolean isSsd() {
        return ssd;
    }

    public void setSsd(boolean ssd) {
        this.ssd = ssd;
    }

    public int getMemory() {
        return memory;
    }

    public void setMemory(int memory) {
        this.memory = memory;
    }

    public double getPerformancee() {
        return performancee;
    }

    public int getPerformance() {
        return 0;
    }

    public String showDetails() {
        return "Price:" + getPrice() + " " + "Model:" + getModel() + " " + "Count:" + getCount() + " " + "Cpu:" + getCpu() + " " + "Ram:" + getRam() + " " + "Ssd:" + ssd + " " + "Memory:" + memory + " " + "Performance:" + performancee;

    }
}
