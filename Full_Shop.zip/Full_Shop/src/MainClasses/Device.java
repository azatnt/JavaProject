package MainClasses;

import java.io.Serializable;

public abstract class Device extends Goods implements Serializable {
    private String cpu;
    private int ram;

    public Device(){}
    public Device(double price, String model, int count, String cpu, int ram) {
        super(price, model, count);
        this.cpu = cpu;
        this.ram = ram;
    }

    public abstract int getPerformance();

    public Device(String cpu, int ram) {
        this.cpu = cpu;
        this.ram = ram;
    }

    public Device(double price, String model, int count, int sold, String cpu, int ram) {
        super(price, model, count, sold);
        this.cpu = cpu;
        this.ram = ram;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    @Override
    public String toString() {
        return "cpu='" + cpu + '\'' +
                ", ram=" + ram;
    }
}
