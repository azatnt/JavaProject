package MainClasses;

import java.io.Serializable;

public abstract class Goods implements Serializable {
    private double price;
    private String model;
    private int count;
    private int sold;
    private double income;
    public abstract  String showDetails();

    public Goods () {}

    public Goods (double price, String model, int count) {
        this.price = price;
        this.model = model;
        this.count = count;
    }

    public Goods(double price, String model, int count, int sold) {
        this.price = price;
        this.model = model;
        this.count = count;
        this.sold = sold;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) { this.price = price; }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getSold() {
        return sold;
    }

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }

    @Override
    public String toString() {
        return "price=" + price +
                ", model='" + model + '\'' +
                ", count=" + count +
                ", sold=" + sold;
    }

}


