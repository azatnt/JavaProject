package MainClasses;

import java.io.Serializable;

public class Laptop extends Computer implements Serializable {
    private double weight;
    private boolean touch;
    private double performancee = 0;
    private double income;

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public Laptop(String cpu, int ram, boolean ssd, int memory, double weight, boolean touch) {
        super(cpu, ram, ssd, memory);
        this.weight = weight;
        this.touch = touch;
    }

    public Laptop(double price, String model, int count, String cpu, int ram, boolean ssd, int memory, double weight, boolean touch) {
        super(price, model, count, cpu, ram, ssd, memory);
        this.weight = weight;
        this.touch = touch;
    }

    public Laptop(double price, String model, int count, String cpu, int ram, boolean ssd, int memory, double weight, boolean touch, int sold, double income) {
        super(price, model, count, sold, cpu, ram, ssd, memory);
        this.weight = weight;
        this.touch = touch;
        this.income = income;
    }

    public Laptop(double price, String model, int count, int sold, String cpu, int ram, boolean ssd, int memory, double weight, boolean touch) {
        super(price, model, count, sold, cpu, ram, ssd, memory);
        this.weight = weight;
        this.touch = touch;
    }

    public Laptop(double price, String model, int count, String cpu, int ram, boolean ssd, int memory, double weight, boolean touch,  double performance) {
        super(price,model,count,cpu,ram,ssd,memory);
        this.weight = weight;
        this.touch = touch;
        this.performancee = performance;
    }


    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public boolean isTouch() {
        return touch;
    }

    public void setTouch(boolean touch) {
        this.touch = touch;
    }

    public String showDetails(){
        return "Price:" + getPrice() + " " + "Model:" + getModel() + " "  + "Count:" + getCount() + " "  + "Cpu:" + getCpu() + " " + "Ram:" + getRam() + " "  + "Ssd:" + isSsd() + " "  + "Memory:" + getMemory() + " " + "Weight:" + weight + " "  + "Touch:" + touch + " " + "Performance: " + performancee;
    }



}
