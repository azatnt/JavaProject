package MainClasses;

import java.io.Serializable;

public class Smartphone extends Device implements Serializable {
    private double mgpx;
    private String generation;
    private double performancee = 0;
    private double income;
    public Smartphone(String cpu, int ram, double mgpx, String generation) {
        super(cpu, ram);
        this.mgpx = mgpx;
        this.generation = generation;
    }

    public Smartphone(double price, String model, int count, String cpu, int ram, double mgpx, String generation) {
        super(price, model, count, cpu, ram);
        this.mgpx = mgpx;
        this.generation = generation;
    }

    public Smartphone(double price, String model, int count, String cpu, int ram, double mgpx, String generation, int sold, double income) {
        super(price, model, count, sold, cpu, ram);
        this.mgpx = mgpx;
        this.generation = generation;
        this.income = income;

    }

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public Smartphone(double price, String model, int count, int sold, String cpu, int ram, double mgpx, String generation) {
        super(price, model, count, sold, cpu, ram);
        this.mgpx = mgpx;
        this.generation = generation;
    }

    public Smartphone(double price, String model, int count, String cpu, int ram, double mgpx, String generation, double performance) {
        super(price,model,count,cpu,ram);
        this.mgpx = mgpx;
        this.generation = generation;
        this.performancee = performance;
    }
    public Smartphone(double price, String model, int count, String cpu, int ram, double mgpx, String generation, double performance, int sold, double income) {
        super(price,model,count,sold,cpu,ram);
        this.mgpx = mgpx;
        this.generation = generation;
        this.performancee = performance;
        this.income=income;
    }
    public double getPerformancee() {
        return performancee;
    }

    public void setPerformancee(double performancee) {
        this.performancee = performancee;
    }

    public double getMgpx() {
        return mgpx;
    }

    public void setMgpx(double mgpx) {
        this.mgpx = mgpx;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public String showDetails() {
        return "Price:" + getPrice() + " " + "Model:" + getModel() + " " + "Count:" + getCount() + " " + "Cpu:" + getCpu() + " " + "Ram:" + getRam() + " " + "Megapixel: " + mgpx + " " + "Generation:" + getGeneration() + " " + "Performance:" + performancee;
    }

    public int getPerformance() {
        return 400;
    }

    @Override
    public String toString() {
        return "mgpx=" + mgpx +
                ", generation='" + generation + '\'';
    }
}
