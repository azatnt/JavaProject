package MainClasses;

import java.io.Serializable;

public class Sneaker extends Wearing implements Serializable {
    private double income;
    private String season;

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public Sneaker(double price, String model, int count, String size, String color, String season) {
        super(price, model, count, size, color);
        this.season = season;
    }

    public Sneaker(double price, String model, int count, int sold, String size, String color, String season) {
        super(price, model, count, sold, size, color);
        this.season = season;
    }

    public Sneaker(String size, String color, String season) {
        super(size, color);
        this.season = season;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    @Override
    public String getCategories() {
        return null;
    }

    @Override
    public String showDetails() {
        return "Price:" + getPrice() + " " + "Model:" + getModel() + " " + "Count:" + getCount() + " " + "Size:" + getSize() + " " + "Color:" + getColor() + " " + "Season:" + getSeason();
    }

}
