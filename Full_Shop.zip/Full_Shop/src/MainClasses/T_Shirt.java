package MainClasses;

import java.io.Serializable;

public class T_Shirt extends Wearing implements Serializable {
    private String material;
    private double income;

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public T_Shirt(double price, String model, int count, String size, String color, String material) {
        super(price, model, count, size, color);
        this.material = material;
    }

    public T_Shirt(double price, String model, int count, int sold, String size, String color, String material) {
        super(price, model, count, sold, size, color);
        this.material = material;
    }

    public T_Shirt(String size, String color, String material) {
        super(size, color);
        this.material = material;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    @Override
    public String getCategories() {
        return null;
    }

    @Override
    public String showDetails() {
        return "Price:" + getPrice() + " " + "Model:" + getModel() + " " + "Count:" + getCount() + " " + "Size:" + getSize() + " " + "Color:" + getColor() + " " + "Material:" + getMaterial();
    }
}
