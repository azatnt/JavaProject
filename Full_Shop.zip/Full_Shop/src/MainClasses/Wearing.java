package MainClasses;

import java.io.Serializable;

public abstract class Wearing extends Goods implements Serializable {
    private String size;
    private String color;
    public abstract  String getCategories();

    public Wearing(double price, String model, int count, String size, String color) {
        super(price, model, count);
        this.size = size;
        this.color = color;
    }

    public Wearing(double price, String model, int count, int sold, String size, String color) {
        super(price, model, count, sold);
        this.size = size;
        this.color = color;
    }

    public Wearing(String size, String color){
        this.size = size;
        this.color = color;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
