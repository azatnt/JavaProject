package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.Laptop;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AddLaptop {
        static AdminMethods adminMethods = new AdminMethods();
        static double getPerformancee;
        private ObservableList<String> modelChoices = FXCollections.observableArrayList("Apple", "Acer", "Asus", "DELL", "Fujitsu", "HP", "Lenovo","Samsung");
        private ObservableList<String> cpuChoices = FXCollections.observableArrayList("Core i3", "Core i5","Core i7", "Core i9");
        private ObservableList<Integer> ramChoices = FXCollections.observableArrayList(4, 6, 8, 12, 16, 32);
        private ObservableList<Integer> memoryChoices = FXCollections.observableArrayList(128, 256, 512, 1024, 2048);

        @FXML
        private void handleYesBox(){
            if(YesBox.isSelected()){
                NoBox.setSelected(false);
            }
        }

        @FXML
        private void handleNoBox(){
            if(NoBox.isSelected()){
                YesBox.setSelected(false);
            }
        }

        @FXML
        private void handleYesTouchBox(){
            if(YesBoxTouch.isSelected()){
                NoBoxTouch.setSelected(false);
            }
        }

        @FXML
        private void handleNoTouchBox(){
            if(NoBoxTouch.isSelected()){
                YesBoxTouch.setSelected(false);
            }
        }

        @FXML
        private ResourceBundle resources;

        @FXML
        private URL location;

        @FXML
        private Button AddBtn;

        @FXML
        private ChoiceBox<String> ModelChoice;

        @FXML
        private TextField Price_field;

        @FXML
        private ChoiceBox<String> CpuChoiceBox;

        @FXML
        private CheckBox YesBox;

        @FXML
        private CheckBox NoBox;

        @FXML
        private ChoiceBox<Integer> MemoryChoiceBox;

        @FXML
        private ChoiceBox<Integer> RamChoiceBox;

        @FXML
        private TextField Quantity_field;

        @FXML
        private CheckBox YesBoxTouch;

        @FXML
        private CheckBox NoBoxTouch;

        @FXML
        private TextField Weight_field;

        @FXML
        private Button BackBtn;


        @FXML
        void initialize() {

            ModelChoice.setItems(modelChoices);
            RamChoiceBox.setItems(ramChoices);
            MemoryChoiceBox.setItems(memoryChoices);
            CpuChoiceBox.setItems(cpuChoices);

            BackBtn.setOnAction(event -> {
                BackBtn.getScene().getWindow().hide();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/FXMLfiles/Add_Product.fxml"));
                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.show();
            });

            AddBtn.setOnAction(event -> {
                String model = ModelChoice.getValue();
                int ram = RamChoiceBox.getValue();
                int memory = MemoryChoiceBox.getValue();
                int price = Integer.parseInt(Price_field.getText());
                int count = Integer.parseInt(Quantity_field.getText());
                double weight = Double.parseDouble(Weight_field.getText());
                String cpu = CpuChoiceBox.getValue();
                if (cpu.equals("Core i3")) {
                    getPerformancee = 3.00;
                } else if (cpu.equals("Core i5")) {
                    getPerformancee = 3.50;
                } else if (cpu.equals("Core i7")) {
                    getPerformancee = 4.00;
                } else if (cpu.equals("Core i9")) {
                    getPerformancee = 4.55;
                }
                boolean ssd = false;
                if (YesBox.isSelected()) {
                    ssd = true;
                } else if (NoBox.isSelected()) {
                    ssd = false;
                }
                boolean touch = false;
                if (YesBoxTouch.isSelected()) {
                    touch = true;
                } else if (NoBoxTouch.isSelected()) {
                    touch = false;
                }
                adminMethods.addLaptop(new Laptop(price, model, count, cpu, ram, ssd, memory, weight, touch, getPerformancee));
                showLaptops();

            });
        }
            public static void showLaptops() {
                for (int i = 0; i < adminMethods.sizeLaptop(); i++) {
                    System.out.println(" --- " + i + " --- \n" + adminMethods.getStrLaptop(i));
                }
            }
    }


