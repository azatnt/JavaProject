package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.Smartphone;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AddSmartphone {

    static AdminMethods adminMethods = new AdminMethods();
    static double getPerformancee;
    private ObservableList<String> modelChoices = FXCollections.observableArrayList("Apple", "Samsung", "Sony", "HTC", "Motorola", "Nokia", "LG", "Huawei","Meizu", "Oppo", "Xiaomi");
    private ObservableList<String> cpuChoices = FXCollections.observableArrayList("A13", "Snapdragon 750","Kirin", "Exynos 9820", "Helio P70");
    private ObservableList<Integer> ramChoices = FXCollections.observableArrayList(2, 4, 6, 8);
    private ObservableList<Integer> mpxChoices = FXCollections.observableArrayList(8, 12, 16, 20, 24);


    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button AddBtn;

    @FXML
    private ChoiceBox<String> ModelChoice;

    @FXML
    private TextField Price_field;

    @FXML
    private ChoiceBox<String> CpuChoiceBox;

    @FXML
    private ChoiceBox<Integer> MgpxChoiceBox;

    @FXML
    private Text MgpxChoice;

    @FXML
    private ChoiceBox<Integer> RamChoiceBox;

    @FXML
    private TextField Quantity_field;

    @FXML
    private Button BackBtn;

    @FXML
    private TextField Generation_field;

    @FXML
    void initialize() {

        ModelChoice.setItems(modelChoices);
        CpuChoiceBox.setItems(cpuChoices);
        RamChoiceBox.setItems(ramChoices);
        MgpxChoiceBox.setItems(mpxChoices);

        BackBtn.setOnAction(event -> {
            BackBtn.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Add_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

        AddBtn.setOnAction(event -> {
            String model = ModelChoice.getValue();
            int ram = RamChoiceBox.getValue();
            int mpx = MgpxChoiceBox.getValue();
            int price = Integer.parseInt(Price_field.getText());
            int count = Integer.parseInt(Quantity_field.getText());
            String generation = Generation_field.getText();
            String cpu = CpuChoiceBox.getValue();
            if(cpu.equals("A13"))
            {
                getPerformancee = 3.00;
            }
            else if(cpu.equals("Snapdragon 750"))
            {
                getPerformancee = 2.80;
            }
            else if(cpu.equals("Kirin"))
            {
                getPerformancee = 2.60;
            }
            else if(cpu.equals("Exynos 9820"))
            {
                getPerformancee = 2.40;
            }
            else if(cpu.equals("Helio P20"))
            {
                getPerformancee = 2.00;
            }

            adminMethods.addSmartphone(new Smartphone(price, model, count, cpu, ram, mpx, generation, getPerformancee));
            showSmartphones();
        });

    }

    public static void showSmartphones() {
        for (int i = 0; i < adminMethods.sizeSmartphone(); i++) {
            System.out.println(" --- " + i + " --- \n" + adminMethods.getStrSmartphone(i));
        }
    }
}
