package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.Smartphone;
import MainClasses.Sneaker;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AddSneaker {

    static AdminMethods adminMethods = new AdminMethods();
    private ObservableList<String> modelChoices = FXCollections.observableArrayList("Adidas", "Air_Jordan", "Balenciaga", "Lacoste", "New_Balance", "Puma", "Reebok");
    private ObservableList<String> seasonChoices = FXCollections.observableArrayList("Summer", "Spring", "Autumn", "Winter", "Multi");
    private ObservableList<String> sizeChoices = FXCollections.observableArrayList("37-38", "39-40", "41-42", "43-44", "45-46", "35-36");


    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button AddBtn;

    @FXML
    private ChoiceBox<String> ModelChoice;

    @FXML
    private TextField Price_field;

    @FXML
    private ChoiceBox<String> SizeChoice;

    @FXML
    private ChoiceBox<String> SeasonChoice;

    @FXML
    private TextField Quantity_field;

    @FXML
    private Button BackBtn;

    @FXML
    private TextField Color_field;

    @FXML
    void initialize() {

        ModelChoice.setItems(modelChoices);
        SizeChoice.setItems(sizeChoices);
        SeasonChoice.setItems(seasonChoices);

        BackBtn.setOnAction(event -> {
            BackBtn.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Add_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

        AddBtn.setOnAction(event -> {
            String model = ModelChoice.getValue();
            String size = SizeChoice.getValue();
            String season = SeasonChoice.getValue();
            String color = Color_field.getText();
            int count = Integer.parseInt(Quantity_field.getText());
            double price = Integer.parseInt(Price_field.getText());

            adminMethods.addSneaker(new Sneaker(price, model, count, size, color, season));
            showSneaker();
        });

    }
    public static void showSneaker() {
        for (int i = 0; i < adminMethods.sizeSneaker(); i++) {
            System.out.println(" --- " + i + " --- \n" + adminMethods.getStrSneaker(i));
        }
    }
}
