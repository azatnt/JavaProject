package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.T_Shirt;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AddTShirt {

    static AdminMethods adminMethods = new AdminMethods();
    private ObservableList<String> modelChoices = FXCollections.observableArrayList("Armain", "Chanel", "Gucci", "Tommy_Hilfiger", "Louis_Viton", "Prada", "Ralph_Lauren", "Vercase");
    private ObservableList<String> materialChoices = FXCollections.observableArrayList("Cotton", "Flax", "Wool", "Denim", "Leather", "Silk", "Nylon", "Polyester");
    private ObservableList<String> sizeChoices = FXCollections.observableArrayList("XS", "S", "M", "L", "XL", "XXL");

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button AddBtn;

    @FXML
    private ChoiceBox<String> ModelChoice;

    @FXML
    private TextField Price_field;

    @FXML
    private ChoiceBox<String> SizeChoice;

    @FXML
    private ChoiceBox<String> MaterialChoice;

    @FXML
    private TextField Quantity_field;

    @FXML
    private Button BackBtn;

    @FXML
    private TextField Color_field;

    @FXML
    void initialize() {
        BackBtn.setOnAction(event -> {
            BackBtn.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Add_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

        ModelChoice.setItems(modelChoices);
        MaterialChoice.setItems(materialChoices);
        SizeChoice.setItems(sizeChoices);

        AddBtn.setOnAction(event -> {
            String model = ModelChoice.getValue();
            String material = MaterialChoice.getValue();
            String size = SizeChoice.getValue();

            int price = Integer.parseInt(Price_field.getText());
            String color = Color_field.getText();
            int count = Integer.parseInt(Quantity_field.getText());

            adminMethods.addTShirt(new T_Shirt(price, model, count, size, color, material));
            showTShirts();
        });

    }
    public static void showTShirts() {
        for (int i = 0; i < adminMethods.sizeTShirt(); i++) {
            System.out.println(" --- " + i + " --- \n" + adminMethods.getStrTShirt(i));
        }
    }

}
