package sample;

import MainClasses.*;

import java.util.ArrayList;

public class AdminMethods {



    ArrayList<Computer> computers = new ArrayList<>();
    ArrayList<Laptop> laptops = new ArrayList<>();
    ArrayList<Smartphone> smartPhones = new ArrayList<>();
    ArrayList<T_Shirt> tshirts = new ArrayList<>();
    ArrayList<Sneaker> sneakers = new ArrayList<>();



    public void addComputer(Computer computer)
    {
        computers.add(computer);
    }
    public int sizeComputer()
    {
        return computers.size();
    }
    public Computer getComputer(int index)
    {
        return computers.get(index);
    }
    public String getStrComputer(int index){
        return computers.get(index).showDetails();
    }
    public void removeComputer(int index)
    {
        computers.remove(index);
    }
    public void buyComputer(int index, int amount)
    {
        computers.get(index).setCount(computers.get(index).getCount()-amount);
        computers.get(index).setSold(computers.get(index).getSold()+amount);
    }

    public void addLaptop(Laptop laptop)
    {
        laptops.add(laptop);
    }
    public int sizeLaptop()
    {
        return laptops.size();
    }
    public Laptop getLaptop(int index)
    {
        return laptops.get(index);
    }
    public String getStrLaptop(int index)
    {
        return laptops.get(index).showDetails();
    }
    public void removeLaptop(int index)
    {
        laptops.remove(index);
    }
    public void buyLaptop(int index, int amount)
    {
        laptops.get(index).setCount(laptops.get(index).getCount() - amount);
        laptops.get(index).setSold(laptops.get(index).getSold() + amount);
    }

    public void addSmartphone(Smartphone smartphone)
    {
        smartPhones.add(smartphone);
    }
    public int sizeSmartphone()
    {
        return smartPhones.size();
    }
    public String getStrSmartphone(int index)
    {
        return smartPhones.get(index).showDetails();
    }
    public Smartphone getSmartphone(int index)
    {
        return smartPhones.get(index);
    }
    public void removeSmartphone(int index)
    {
        smartPhones.remove(index);
    }
    public void buySmartphone(int index, int amount)
    {
        smartPhones.get(index).setCount(smartPhones.get(index).getCount() - amount);
        smartPhones.get(index).setSold(smartPhones.get(index).getSold() + amount);
    }

    public void addTShirt(T_Shirt t_shirt)
    {
        tshirts.add(t_shirt);
    }
    public int sizeTShirt()
    {
        return tshirts.size();
    }
    public T_Shirt getTShirt(int index)
    {
        return tshirts.get(index);
    }
    public String getStrTShirt(int index)
    {
        return tshirts.get(index).showDetails();
    }
    public void removeTShirt(int index)
    {
        tshirts.remove(index);
    }
    public void buyTShirt(int index, int amount)
    {
        tshirts.get(index).setCount(tshirts.get(index).getCount() - amount);
        tshirts.get(index).setSold(tshirts.get(index).getSold() + amount);
    }

    public void addSneaker(Sneaker sneaker)
    {
        sneakers.add(sneaker);
    }
    public int sizeSneaker()
    {
        return sneakers.size();
    }
    public Sneaker getSneaker(int index)
    {
        return sneakers.get(index);
    }
    public String getStrSneaker(int index)
    {
        return sneakers.get(index).showDetails();
    }
    public void removeSneaker(int index)
    {
        sneakers.remove(index);
    }
    public void buySneaker(int index, int amount)
    {
        tshirts.get(index).setCount(sneakers.get(index).getCount() - amount);
        tshirts.get(index).setSold(sneakers.get(index).getSold() + amount);
    }

}