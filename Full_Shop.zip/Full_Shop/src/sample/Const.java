package sample;

public class Const {
    public static final String USER_TABLE = "Users";

    public static final String USERS_ID = "idUsers";
    public static final String USERS_NAME = "Name";
    public static final String USER_SURNAME = "Surname";
    public static final String USER_LOGIN = "Login";
    public static final String USER_PASSWORD = "Password";
    public static final String USER_GENDER = "Gender";
}
