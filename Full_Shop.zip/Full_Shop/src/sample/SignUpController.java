package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SignUpController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField Sign_Up_Name;

    @FXML
    private PasswordField Sign_Up_Password;

    @FXML
    private Button Sign_Up_Button;

    @FXML
    private Button Back;

    @FXML
    private TextField Sign_Up_Surname;

    @FXML
    private TextField Sign_Up_Login;

    @FXML
    private CheckBox Sign_Up_Check_Male;

    @FXML
    private CheckBox Sign_Up_Check_Female;

    @FXML
    void initialize() {

        Sign_Up_Button.setOnAction(event -> {
            Sign_Up_newUser();
        });


        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/sample.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }

    private void Sign_Up_newUser() {
        DatabaseHandler dbHandler = new DatabaseHandler();

        String Name = Sign_Up_Name.getText();
        String Surname = Sign_Up_Surname.getText();
        String Login = Sign_Up_Login.getText();
        String Password = Sign_Up_Password.getText();
        String Gender = "";
        if(Sign_Up_Check_Male.isSelected())
            Gender = "Male";
        else
        {
            Gender = "Female";
        }

        User user = new User(Name, Surname, Login, Password, Gender);

        dbHandler.signUpUser(user);
    }
}
