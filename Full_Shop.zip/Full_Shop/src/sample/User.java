package sample;

public class User {
    private String Name;
    private String Surname;
    private String Login;
    private String Password;
    private String Gender;


    public User(){}

    public User(String Name, String Surname, String Login, String Password, String Gender)
    {
        this.Name = Name;
        this.Surname = Surname;
        this.Login = Login;
        this.Password = Password;
        this.Gender = Gender;
    }

    public void setName(String name) {
        Name = name;
    }
    public String getName() {
        return Name;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }
    public String getSurname() {
        return Surname;
    }

    public void setLogin(String login) {
        Login = login;
    }
    public String getLogin() {
        return Login;
    }

    public void setPassword(String password) {
        Password = password;
    }
    public String getPassword() {
        return Password;
    }

    public void setGender(String gender) {
        Gender = gender;
    }
    public String getGender() {
        return Gender;
    }
}
