package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.Smartphone;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class butSmartphone {
    private double income = 0;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TableView<Smartphone> tableView;

    @FXML
    private TableColumn<Smartphone, String> ModelColumn;

    @FXML
    private TableColumn<Smartphone, String> CpuColumn;

    @FXML
    private TableColumn<Smartphone, Integer> RamColumn;

    @FXML
    private TableColumn<Smartphone, Double> MGPXColumn;

    @FXML
    private TableColumn<Smartphone, Integer> QuantityColumn;

    @FXML
    private TableColumn<Smartphone, Double> PriceColumn;

    @FXML
    private TableColumn<Smartphone, String> GenerationColumn;

    @FXML
    private TextField BuyID;

    @FXML
    private Button Buy;

    @FXML
    private TextField Count;

    public ObservableList<Smartphone> getSmartphone() {
        ObservableList<Smartphone> smartphones = FXCollections.observableArrayList();
        for (int i = 0; i < AddSmartphone.adminMethods.sizeSmartphone(); i++){
            double price = AddSmartphone.adminMethods.getSmartphone(i).getPrice();
            String model = AddSmartphone.adminMethods.getSmartphone(i).getModel();
            int count = AddSmartphone.adminMethods.getSmartphone(i).getCount();
            String cpu = AddSmartphone.adminMethods.getSmartphone(i).getCpu();
            int ram = AddSmartphone.adminMethods.getSmartphone(i).getRam();
            double mgpx = AddSmartphone.adminMethods.getSmartphone(i).getMgpx();
            String generation = AddSmartphone.adminMethods.getSmartphone(i).getGeneration();
            double performance = AddSmartphone.adminMethods.getSmartphone(i).getPerformance();
            smartphones.add(new Smartphone(price,model,count,cpu,ram,mgpx,generation, performance));
        }

        return smartphones;
    }

    @FXML
    void initialize() {

        PriceColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, Double>("price"));
        ModelColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, String>("model"));
        QuantityColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, Integer>("count"));
        CpuColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, String>("cpu"));
        RamColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, Integer>("ram"));
        MGPXColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, Double>("mgpx"));
        GenerationColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, String>("generation"));
        tableView.setItems(getSmartphone());

        Buy.setOnAction(event -> {
            String indexProduct = BuyID.getText();
            int countBuy = Integer.parseInt(Count.getText());
            for(int i=0; i<AddSmartphone.adminMethods.sizeSmartphone(); i++)
            {
                int i1 = Integer.parseInt(indexProduct);
                if(i1 == i)
                {
                    AddSmartphone.adminMethods.buySmartphone(i1, countBuy);
                    income = AddSmartphone.adminMethods.getSmartphone(i1).getPrice() * AddSmartphone.adminMethods.getSmartphone(i1).getSold();
                    AddSmartphone.adminMethods.getSmartphone(i1).setIncome(income);
                }
            }
            tableView.setItems(getSmartphone());
            BuyID.setText("");
            Count.setText("");
        });


        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Buy_All_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

    }
}

