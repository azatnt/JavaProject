package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.Computer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class deleteComputer {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TableView<Computer> tableView;

    @FXML
    private TableColumn<Computer, String> ModelColumn;

    @FXML
    private TableColumn<Computer, String> CpuColumn;

    @FXML
    private TableColumn<Computer, Integer> MemoryColumn;

    @FXML
    private TableColumn<Computer, Integer> RamColumn;

    @FXML
    private TableColumn<Computer, Boolean> SSDColumn;

    @FXML
    private TableColumn<Computer, Integer> QuantityColumn;

    @FXML
    private TableColumn<Computer, Double> Price_Column;

    @FXML
    private Button Delete;

    @FXML
    private TextField DeleteID;

    public ObservableList<Computer> getComputer() {
        ObservableList<Computer> comp = FXCollections.observableArrayList();
        for (int i = 0; i < AddComputer.adminMethods.sizeComputer(); i++){
            double price = AddComputer.adminMethods.getComputer(i).getPrice();
            String model = AddComputer.adminMethods.getComputer(i).getModel();
            int count = AddComputer.adminMethods.getComputer(i).getCount();
            String cpu = AddComputer.adminMethods.getComputer(i).getCpu();
            int ram = AddComputer.adminMethods.getComputer(i).getRam();
            Boolean ssd = AddComputer.adminMethods.getComputer(i).isSsd();
            int memory = AddComputer.adminMethods.getComputer(i).getMemory();
            comp.add(new Computer(price,model,count,cpu,ram,ssd,memory));
        }

        return comp;
    }

    @FXML
    void initialize() {
        Price_Column.setCellValueFactory(new PropertyValueFactory<Computer, Double>("price"));
        ModelColumn.setCellValueFactory(new PropertyValueFactory<Computer, String>("model"));
        QuantityColumn.setCellValueFactory(new PropertyValueFactory<Computer, Integer>("count"));
        CpuColumn.setCellValueFactory(new PropertyValueFactory<Computer, String>("cpu"));
        RamColumn.setCellValueFactory(new PropertyValueFactory<Computer, Integer>("ram"));
        SSDColumn.setCellValueFactory(new PropertyValueFactory<Computer, Boolean>("ssd"));
        MemoryColumn.setCellValueFactory(new PropertyValueFactory<Computer, Integer>("memory"));
        tableView.setItems(getComputer());

        Delete.setOnAction(event -> {
            String indexProduct = DeleteID.getText();
            for(int i=0; i<AddComputer.adminMethods.sizeComputer(); i++)
            {
                int i1 = Integer.parseInt(indexProduct);
                if(i1 == i)
                {
                    AddComputer.adminMethods.removeComputer(i1);
                }
            }
            tableView.setItems(getComputer());
            DeleteID.setText("");
        });



        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Delete_All_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();


        });

    }
}
