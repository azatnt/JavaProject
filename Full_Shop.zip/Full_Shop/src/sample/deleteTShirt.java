package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.T_Shirt;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class deleteTShirt {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TableView<T_Shirt> tableView;

    @FXML
    private TableColumn<T_Shirt, String> ModelColumn;

    @FXML
    private TableColumn<T_Shirt, String> MaterialColumn;

    @FXML
    private TableColumn<T_Shirt, String> ColorColumn;

    @FXML
    private TableColumn<T_Shirt, String> SizeColumn;

    @FXML
    private TableColumn<T_Shirt, Integer> QuantityColumn;

    @FXML
    private TableColumn<T_Shirt, Double> PriceColumn;

    @FXML
    private Button Delete;

    @FXML
    private TextField DeleteID;


    public ObservableList<T_Shirt> getTShirt() {
        ObservableList<T_Shirt> t_shirts = FXCollections.observableArrayList();
        for (int i = 0; i < AddTShirt.adminMethods.sizeTShirt(); i++){
            double price = AddTShirt.adminMethods.getTShirt(i).getPrice();
            String model = AddTShirt.adminMethods.getTShirt(i).getModel();
            int count = AddTShirt.adminMethods.getTShirt(i).getCount();
            String size = AddTShirt.adminMethods.getTShirt(i).getSize();
            String color = AddTShirt.adminMethods.getTShirt(i).getColor();
            String material = AddTShirt.adminMethods.getTShirt(i).getMaterial();
            t_shirts.add(new T_Shirt(price,model,count,size,color,material));
        }

        return t_shirts;
    }

    @FXML
    void initialize() {
        PriceColumn.setCellValueFactory(new PropertyValueFactory<T_Shirt, Double>("price"));
        ModelColumn.setCellValueFactory(new PropertyValueFactory<T_Shirt, String>("model"));
        QuantityColumn.setCellValueFactory(new PropertyValueFactory<T_Shirt, Integer>("count"));
        SizeColumn.setCellValueFactory(new PropertyValueFactory<T_Shirt, String>("size"));
        ColorColumn.setCellValueFactory(new PropertyValueFactory<T_Shirt, String>("color"));
        MaterialColumn.setCellValueFactory(new PropertyValueFactory<T_Shirt, String>("material"));
        tableView.setItems(getTShirt());

        Delete.setOnAction(event -> {
            String indexProduct = DeleteID.getText();
            for(int i=0; i<AddTShirt.adminMethods.sizeTShirt(); i++)
            {
                int i1 = Integer.parseInt(indexProduct);
                if(i1 == i)
                {
                    AddTShirt.adminMethods.removeTShirt(i1);
                }
            }

            tableView.setItems(getTShirt());
            DeleteID.setText("");
        });


        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Delete_All_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

        }
        );
}

}
