package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.Smartphone;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class incomeSmartphone {
    private double incomeTotal = 0;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TableView<Smartphone> tableView;

    @FXML
    private TableColumn<Smartphone, String> ModelColumn;

    @FXML
    private TableColumn<Smartphone, String> CpuColumn;

    @FXML
    private TableColumn<Smartphone, Integer> RamColumn;

    @FXML
    private TableColumn<Smartphone, Double> MGPXColumn;

    @FXML
    private TableColumn<Smartphone, Integer> QuantityColumn;

    @FXML
    private TableColumn<Smartphone, Double> PriceColumn;

    @FXML
    private TableColumn<Smartphone, String> GenerationColumn;

    @FXML
    private TextArea TotalIncome;

    public ObservableList<Smartphone> getSmartphone() {
        ObservableList<Smartphone> smartphones = FXCollections.observableArrayList();
        for (int i = 0; i < AddSmartphone.adminMethods.sizeSmartphone(); i++){
            double price = AddSmartphone.adminMethods.getSmartphone(i).getPrice();
            String model = AddSmartphone.adminMethods.getSmartphone(i).getModel();
            int count = AddSmartphone.adminMethods.getSmartphone(i).getCount();
            String cpu = AddSmartphone.adminMethods.getSmartphone(i).getCpu();
            int ram = AddSmartphone.adminMethods.getSmartphone(i).getRam();
            double mgpx = AddSmartphone.adminMethods.getSmartphone(i).getMgpx();
            String generation = AddSmartphone.adminMethods.getSmartphone(i).getGeneration();
            double performancee = AddSmartphone.adminMethods.getSmartphone(i).getPerformancee();
            int sold = AddSmartphone.adminMethods.getSmartphone(i).getSold();
            double income = AddSmartphone.adminMethods.getSmartphone(i).getIncome();
            smartphones.add(new Smartphone(price,model,count,cpu,ram,mgpx,generation, performancee, sold, income));
            incomeTotal += income;
        }

        return smartphones;
    }

    @FXML
    void initialize() {
        PriceColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, Double>("price"));
        ModelColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, String>("model"));
        QuantityColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, Integer>("count"));
        CpuColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, String>("cpu"));
        RamColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, Integer>("ram"));
        MGPXColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, Double>("mgpx"));
        GenerationColumn.setCellValueFactory(new PropertyValueFactory<Smartphone, String>("generation"));
        tableView.setItems(getSmartphone());
        String total = Double.toString(incomeTotal);
        TotalIncome.setText(total);



        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Income_All_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }
}
