package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.T_Shirt;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class incomeTShirt {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TableView<T_Shirt> tableView;

    @FXML
    private TableColumn<T_Shirt, String> ModelColumn;

    @FXML
    private TableColumn<T_Shirt, String> MaterialColumn;

    @FXML
    private TableColumn<T_Shirt, String> ColorColumn;

    @FXML
    private TableColumn<T_Shirt, String> SizeColumn;

    @FXML
    private TableColumn<T_Shirt, Integer> QuantityColumn;

    @FXML
    private TableColumn<T_Shirt, Double> PriceColumn;

    @FXML
    private TextArea TotalIncome;

    @FXML
    void initialize() {

        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Income_All_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }
}
