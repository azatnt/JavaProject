package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.Laptop;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class seeLaptop {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TableView<Laptop> tableView;

    @FXML
    private TableColumn<Laptop, String> ModelColumn;

    @FXML
    private TableColumn<Laptop, String> CpuColumn;

    @FXML
    private TableColumn<Laptop, Integer> MemoryColumn;

    @FXML
    private TableColumn<Laptop, Integer> RamColumn;

    @FXML
    private TableColumn<Laptop, Boolean> SSDColumn;

    @FXML
    private TableColumn<Laptop, Integer> QuantityColumn;

    @FXML
    private TableColumn<Laptop, Double> PriceColumn;

    @FXML
    private TableColumn<Laptop, Double> WeightColumn;

    @FXML
    private TableColumn<Laptop, Boolean> TouchColumn;

    public ObservableList<Laptop> getLaptop() {
        ObservableList<Laptop> lap = FXCollections.observableArrayList();
        for (int i = 0; i < AddLaptop.adminMethods.sizeLaptop(); i++){
            double price = AddLaptop.adminMethods.getLaptop(i).getPrice();
            String model = AddLaptop.adminMethods.getLaptop(i).getModel();
            int count = AddLaptop.adminMethods.getLaptop(i).getCount();
            String cpu = AddLaptop.adminMethods.getLaptop(i).getCpu();
            int ram = AddLaptop.adminMethods.getLaptop(i).getRam();
            boolean ssd = AddLaptop.adminMethods.getLaptop(i).isSsd();
            int memory = AddLaptop.adminMethods.getLaptop(i).getMemory();
            double weight = AddLaptop.adminMethods.getLaptop(i).getWeight();
            boolean touch = AddLaptop.adminMethods.getLaptop(i).isTouch();
            lap.add(new Laptop(price,model,count,cpu,ram,ssd,memory, weight, touch));
        }


        return lap;
    }


    @FXML
    void initialize() {

        PriceColumn.setCellValueFactory(new PropertyValueFactory<Laptop, Double>("price"));
        ModelColumn.setCellValueFactory(new PropertyValueFactory<Laptop, String>("model"));
        QuantityColumn.setCellValueFactory(new PropertyValueFactory<Laptop, Integer>("count"));
        CpuColumn.setCellValueFactory(new PropertyValueFactory<Laptop, String>("cpu"));
        RamColumn.setCellValueFactory(new PropertyValueFactory<Laptop, Integer>("ram"));
        SSDColumn.setCellValueFactory(new PropertyValueFactory<Laptop, Boolean>("ssd"));
        MemoryColumn.setCellValueFactory(new PropertyValueFactory<Laptop, Integer>("memory"));
        WeightColumn.setCellValueFactory(new PropertyValueFactory<Laptop, Double>("weight"));
        TouchColumn.setCellValueFactory(new PropertyValueFactory<Laptop, Boolean>("touch"));

        tableView.setItems(getLaptop());


        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/See_All_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });



    }
}
