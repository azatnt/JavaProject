package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.Sneaker;
import MainClasses.T_Shirt;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class seeSneaker {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TableView<Sneaker> tableView;

    @FXML
    private TableColumn<Sneaker, String> ModelColumn;

    @FXML
    private TableColumn<Sneaker, String> SeasonColumn;

    @FXML
    private TableColumn<Sneaker, String> ColorColumn;

    @FXML
    private TableColumn<Sneaker, String> SizeColumn;

    @FXML
    private TableColumn<Sneaker, Integer> QuantityColumn;

    @FXML
    private TableColumn<Sneaker, Double> PriceColumn;


    public ObservableList<Sneaker> getSneaker() {
        ObservableList<Sneaker> sneakers = FXCollections.observableArrayList();
        for (int i = 0; i < AddSneaker.adminMethods.sizeSneaker(); i++){
            double price = AddSneaker.adminMethods.getSneaker(i).getPrice();
            String model = AddSneaker.adminMethods.getSneaker(i).getModel();
            int count = AddSneaker.adminMethods.getSneaker(i).getCount();
            String size = AddSneaker.adminMethods.getSneaker(i).getSize();
            String color = AddSneaker.adminMethods.getSneaker(i).getColor();
            String season = AddSneaker.adminMethods.getSneaker(i).getSeason();
            sneakers.add(new Sneaker(price,model,count,size,color,season));
        }

        return sneakers;
    }


    @FXML
    void initialize() {
        PriceColumn.setCellValueFactory(new PropertyValueFactory<Sneaker, Double>("price"));
        ModelColumn.setCellValueFactory(new PropertyValueFactory<Sneaker, String>("model"));
        QuantityColumn.setCellValueFactory(new PropertyValueFactory<Sneaker, Integer>("count"));
        SizeColumn.setCellValueFactory(new PropertyValueFactory<Sneaker, String>("size"));
        ColorColumn.setCellValueFactory(new PropertyValueFactory<Sneaker, String>("color"));
        SeasonColumn.setCellValueFactory(new PropertyValueFactory<Sneaker, String>("season"));
        tableView.setItems(getSneaker());



        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/See_All_Product.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();


        });

    }
}
