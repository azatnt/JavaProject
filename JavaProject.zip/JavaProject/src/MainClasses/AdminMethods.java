package MainClasses;

import SocketServer.Book;

import java.util.ArrayList;

public class AdminMethods {
    ArrayList<Book> books = new ArrayList<>();


    public void addBook(Book book)
    {
        books.add(book);
    }
    public Book getBook(int index)
    {
        return books.get(index);
    }
}
