package MainClasses;

public class Configs {
    protected String dbHost = "localhost";
    protected String dbPort = "3306";
    protected String dbUser = "root";
    protected String dbPass = "Azat12345";
    protected String dbName = "Library";
}
