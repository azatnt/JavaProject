package MainClasses;

public class Const {
    public static final String USER_TABLE = "users";

    public static final String USERS_ID = "idUsers";
    public static final String USERS_NAME = "firstname";
    public static final String USER_SURNAME = "lastname";
    public static final String USER_LOGIN = "username";
    public static final String USER_PASSWORD = "password";
    public static final String USER_ADDRESS = "address";
}
