package MainClasses;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import SocketServer.Reply;
import SocketServer.Request;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sample.animations.Shake;

public class Controller {
    private static String logName;

    public static String getLogName() {
        return logName;
    }

    public static void setLogName(String logName) {
        Controller.logName = logName;
    }

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField Login_field;

    @FXML
    private PasswordField Password_field;

    @FXML
    private Button Login_In_Btn;

    @FXML
    private Button Sign_Up_Btn;



    @FXML
    void initialize() {
        Login_In_Btn.setOnAction(event -> {


            try
            {
                Controller controller = new Controller();
                String login = controller.getLogName();
                Socket socket = new Socket("127.0.0.1", 1999);
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

                String loginText = Login_field.getText().trim();
                String loginPassword = Password_field.getText().trim();

                Request request = new Request("VIEW");
                oos.writeObject(request);

                Reply reply = (Reply)ois.readObject();
                ArrayList<User> list = reply.getUsers();



                for(User user : list)
                {
//                    System.out.println(user);

                    if (loginText.equals("Admin") && loginPassword.equals("123")) {
                        Login_In_Btn.getScene().getWindow().hide();
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLfiles/Admin.fxml"));
                        try {
                            loader.load();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }




                        Parent root = loader.getRoot();
                        Stage stage = new Stage();
                        stage.setScene(new Scene(root));
                        stage.show();
                        break;

                    }

                    if (!loginText.equals("") && !loginPassword.equals("")) {
                        loginUser(loginText, loginPassword);
                        break;
                    }

                    else
                    {
                        System.out.println("We can't find user");
                        break;
                    }
                }




            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }


        });

        Sign_Up_Btn.setOnAction(event -> {
            openNewScene("/FXMLfiles/SignUp.fxml");
        });

    }

    public void openNewScene(String window)
    {
        Sign_Up_Btn.getScene().getWindow().hide();

        FXMLLoader loader = new FXMLLoader(getClass().getResource(window));
        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }


    public void loginUser(String loginText, String loginPassword) {

        DatabaseHandler dbHandler = new DatabaseHandler();
        User user = new User();
        user.setLogin(loginText);
        user.setPassword(loginPassword);
        ResultSet result = dbHandler.getUser(user);




        int count = 0;

        while (true)
        {
            try {
                if (!result.next()) break;
            } catch (SQLException e) {
                e.printStackTrace();
            }
            count++;
        }

        if(count >= 1)
        {
            setLogName(loginText);
            System.out.println(getLogName());
            openNewScene("/FXMLfiles/Consume.fxml");
        }
        else{
            Shake userLoginAnim = new Shake(Login_field);
            Shake userPassAnim = new Shake(Password_field);

            userLoginAnim.playAnim();
            userPassAnim.playAnim();
        }
    }
}
