package MainClasses;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.User;
import SocketServer.Reply;
import SocketServer.Request;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SignUpController{

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private PasswordField Sign_Up_Password;

    @FXML
    private Button Register_Btn;

    @FXML
    private TextField Sign_Up_Login;

    @FXML
    private Button Back;

    @FXML
    private PasswordField Sign_Up_Password_Conf;

    @FXML
    private TextField Sign_Up_Name;

    @FXML
    private TextField Sign_Up_Surname;

    @FXML
    private TextField Sign_Up_Address;

    @FXML
    void initialize() throws IOException, ClassNotFoundException {

        Register_Btn.setOnAction(event -> {
//            DatabaseHandler dbHandler = new DatabaseHandler();

            try {
                Socket socket = new Socket("127.0.0.1", 1999);
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());


                String Name = Sign_Up_Name.getText();
                String Surname = Sign_Up_Surname.getText();
                String Login = Sign_Up_Login.getText();
                String Password = Sign_Up_Password.getText();
                String Address = Sign_Up_Address.getText();


                User user = new User(Name, Surname, Login, Password, Address);
                Request reqUser = new Request("ADD", user);

                oos.writeObject(reqUser);


                Reply rep = (Reply)ois.readObject();
                System.out.println(rep.getCode());


                oos.close();
                ois.close();

                Alert dg = new Alert(Alert.AlertType.INFORMATION);
                dg.setTitle("Dear our costumer");
                dg.setContentText("Our congratulations you SIGNED UP!");
                dg.show();


            }  catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }


//            dbHandler.signUpUser(user);
        });


        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/sample.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }


//    private void Sign_Up_newUser() throws IOException {
//        DatabaseHandler dbHandler = new DatabaseHandler();
//
//        Socket socket = new Socket("localhost", 3306);
//        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
//        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
//
//
//
//
//        String Name = Sign_Up_Name.getText();
//        String Surname = Sign_Up_Surname.getText();
//        String Login = Sign_Up_Login.getText();
//        String Password = Sign_Up_Password.getText();
//        String Address = Sign_Up_Address.getText();
//
//
//        User user = new User(Name, Surname, Login, Password, Address);
//
//
//        dbHandler.signUpUser(user);
//    }
}
