package MainClasses;

import java.io.Serializable;

public class User implements Serializable {
    private int id;
    private String Name;
    private String Surname;
    private String Login;
    private String Password;
    private String Address;
    private int Phone;
    private int Fine;

    public User(String nameUser) {
        this.Name = nameUser;
    }


    public int getPhone() {
        return Phone;
    }

    public void setPhone(int phone) {
        this.Phone = phone;
    }

    public User(){}

    public User(String Name, String Surname, String Login, String Password, String Address)
    {
        this.Name = Name;
        this.Surname = Surname;
        this.Login = Login;
        this.Password = Password;
        this.Address = Address;
    }

    public User(String name, String login, String address, int phone, int fine) {
        this.Name = name;
        this.Login = login;
        this.Address = address;
        this.Phone = phone;
        this.Fine = fine;

    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        Name = name;
    }
    public String getName() {
        return Name;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }
    public String getSurname() {
        return Surname;
    }

    public void setLogin(String login) {
        Login = login;
    }
    public String getLogin() {
        return Login;
    }

    public void setPassword(String password) {
        Password = password;
    }
    public String getPassword() {
        return Password;
    }

    public void setAddress(String address) {
        Address = address;
    }
    public String getAddress() {
        return Address;
    }
}
