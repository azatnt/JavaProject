package SocketServer;

import java.io.Serializable;

public class Book implements Serializable {
    private Integer id;
    private String name;
    private String author;
    private String genre;
    private int row;
    private int shelf;
    private int amount;
    private int price;
    private int ISBN;
    private String description;
    private String address;
    private String phone;
    private String comment;
    private int today;
    private String currDate;



    public Book(String name, int today, String currDate) {
        this.name = name;
        this.today = today;
        this.currDate = currDate;
    }

    public Book(Integer id, String name, String author, String genre, int isbn, int amount, int price, int row, int shelf, String description) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.amount = amount;
        this.price = price;
        this.ISBN = isbn;
        this.genre = genre;
        this.row = row;
        this.shelf = shelf;
        this.description = description;
    }

    public Book(String name) {
        this.name = name;
    }

    public Book(String name, int today) {
        this.name = name;
        this.today = today;
    }

    public Book(int today, String currDate)
    {
        this.currDate = currDate;
        this.today = today;
    }

    public Book(){}

    public Book(String name, String author, String genre, int isbn, int amount, int price, int row, int shelf) {
        this.name = name;
        this.author = author;
        this.amount = amount;
        this.price = price;
        this.ISBN = isbn;
        this.genre = genre;
        this.row = row;
        this.shelf = shelf;

    }

    public Book(String name, String author, String genre, int isbn, int amount, int price, int row, int shelf, String description) {
        this.name = name;
        this.author = author;
        this.amount = amount;
        this.price = price;
        this.ISBN = isbn;
        this.genre = genre;
        this.row = row;
        this.shelf = shelf;
        this.description = description;
    }

    public Book(String name, int price, String address, String phone, String comment) {

//        this.id = id;
        this.name = name;
        this.price = price;
        this.address = address;
        this.phone = phone;
        this.address = address;
        this.comment = comment;
    }

    public int getToday() {
        return today;
    }

    public void setToday(int today) {
        this.today = today;
    }

    public String getCurrDate() {
        return currDate;
    }

    public void setCurrDate(String currDate) {
        this.currDate = currDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getISBN() {
        return ISBN;
    }

    public void setISBN(int ISBN) {
        this.ISBN = ISBN;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getShelf() {
        return shelf;
    }

    public void setShelf(int shelf) {
        this.shelf = shelf;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }



//    public Book(int id, String name)
//    {
//        this.id = id;
//        this.name = name;
//    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", genre='" + genre + '\'' +
                ", startRead'" + currDate + '\'' +
                ", readingPeriod'" + today + '\'' +
                '}';
    }

}
