package SocketServer;

import MainClasses.User;
import javafx.scene.control.Alert;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



public class ClientHandler extends Thread {

    private Socket socket;
    private ObjectOutputStream oos = null;
    private ObjectInputStream ois = null;
    private Connection conn;

    public ClientHandler(Socket socket, Connection conn){
        this.conn = conn;
        this.socket = socket;

        try {
            oos = new ObjectOutputStream(socket.getOutputStream());
            ois = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public ArrayList<User> getAllUsers()
    {
        ArrayList<User> list = new ArrayList<>();

        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * from users");
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                String name = rs.getString("firstname");
                String lastname = rs.getString("lastname");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String address = rs.getString("address");

                list.add(new User(name, lastname, username, password, address));

            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public ArrayList<User> getOneUser(String login)
    {
        ArrayList<User> listOneUser = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE username=?");
            ps.setString(1, login);
            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                String name = rs.getString("firstname");
                String lastname = rs.getString("lastname");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String address = rs.getString("address");

                listOneUser.add(new User(name, lastname, username, password, address));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listOneUser;
    }

    public ArrayList<User> getBlackList()
    {
        ArrayList<User> list = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM BlackList");
            ResultSet rs = ps.executeQuery();

            while (rs.next())
            {
                String name = rs.getString("Name");
                String login = rs.getString("Login");
                String address = rs.getString("Address");
                int phone = rs.getInt("Phone");
                int fine = rs.getInt("Fine");

                list.add(new User(name, login, address, phone, fine));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public ArrayList<Book> getReadingUsers()
    {
        ArrayList<User> list = new ArrayList<>();
        ArrayList<Book> list1 = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Reading_User");
            ResultSet rs = ps.executeQuery();

            while (rs.next())
            {
//                String nameUser = rs.getString("NameOfUser");
                String nameBook = rs.getString("NameOfBook");
                int readingPeriod = rs.getInt("ReadingPeriod");
                String startRead = rs.getString("StartRead");

//                list.add(new User(nameUser));
                list1.add(new Book(nameBook, readingPeriod, startRead));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list1;

    }

    public ArrayList<Book> checkBlacklist()
    {
        ArrayList<Book> list = new ArrayList<>();

        try {
            PreparedStatement ps = conn.prepareStatement("SELECT ReadingPeriod, StartRead FROM Reading_User");
            ResultSet rs = ps.executeQuery();

            while (rs.next())
            {

                int readingPeriod = rs.getInt("ReadingPeriod");
                String startRead = rs.getString("StartRead");


                list.add(new Book(readingPeriod, startRead));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;

    }

    public ArrayList<Book> getAllBooks()
    {
        ArrayList<Book> list = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * from Books");
            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {
                Integer id = rs.getInt("idBooks");
                String name = rs.getString("name");
                String author = rs.getString("author");
                String genre = rs.getString("genre");
                int isbn = rs.getInt("isbn");
                int amount = rs.getInt("amount");
                int price = rs.getInt("price");
                int row = rs.getInt("rowBook");
                int shelf = rs.getInt("shelfBook");
                String description = rs.getString("description");

                list.add(new Book(id, name, author, genre, isbn, amount, price, row, shelf, description));

            }
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public void Order(Book book)
    {
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO OrderBook (NameBook, PriceBook, AddressCustom, PhoneCustom, CommentCustom) VALUES(?,?,?,?,?)");
            ps.setString(1, book.getName());
            ps.setInt(2, book.getPrice());
            ps.setString(3, book.getAddress());
            ps.setString(4, book.getPhone());
            ps.setString(5, book.getComment());

            ps.executeUpdate();
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void addUser(User user){
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users (firstname, lastname, username, password, address) VALUES(?,?,?,?,?)");
            ps.setString(1, user.getName());
            ps.setString(2, user.getSurname());
            ps.setString(3, user.getLogin());
            ps.setString(4, user.getPassword());
            ps.setString(5, user.getAddress());


            ps.executeUpdate();
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void addBook(Book book)
    {
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Books (idBooks, name, author, genre, isbn, amount, price, rowBook, shelfBook, description) VALUES(NULL,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, book.getName());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getGenre());
            ps.setInt(4, book.getISBN());
            ps.setInt(5, book.getAmount());
            ps.setInt(6, book.getPrice());
            ps.setInt(7, book.getRow());
            ps.setInt(8, book.getShelf());
            ps.setString(9, book.getDescription());

            ps.executeUpdate();
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void addReadingUser(User user, Book book)
    {
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Reading_User (NameOfUser, NameOfBook, ReadingPeriod, StartRead) VALUES(?,?,?,?)");
            ps.setString(1, user.getName());
            ps.setString(2, book.getName());
            ps.setInt(3, book.getToday());
            ps.setString(4, book.getCurrDate());

            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void updateBook(Book book)
    {
        try {
            PreparedStatement ps = conn.prepareStatement("UPDATE Books SET name=?, author=?, genre=?, isbn=?, amount=?, price=?, rowBook=?, shelfBook=?, description=? WHERE idBooks = ?");
            ps.setString(1, book.getName());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getGenre());
            ps.setInt(4, book.getISBN());
            ps.setInt(5, book.getAmount());
            ps.setInt(6, book.getPrice());
            ps.setInt(7, book.getRow());
            ps.setInt(8, book.getShelf());
            ps.setString(9, book.getDescription());
            ps.setInt(10, book.getId());


            ps.executeUpdate();
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();

        }
    }



    public void removeBook(int id){
        try {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM Books where idBooks=?");
            ps.setInt(1, id);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    public void run(){
        while(true){
            Request req = null;
            try {
                req = (Request)ois.readObject();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            if(req.getCode().equals("VIEW_BOOK")){
                Reply rep = new Reply();
                ArrayList<Book> books = getAllBooks();

                for(Book book : books){
                    rep.addBook(book);
                }

                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("VIEW"))
            {
                Reply rep = new Reply();
                ArrayList<User> users = getAllUsers();

                for(User user : users)
                {
                    rep.addUser(user);
                }
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("GET_READING_USERS"))
            {
                Reply rep = new Reply();
                ArrayList<Book> books = getReadingUsers();
                for(Book book : books)
                {
                    rep.addBook(book);
                }
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            if(req.getCode().equals("GET_USER_BY_LOGIN"))
            {
                Reply rep = new Reply();
                ArrayList<User> users = getOneUser(req.getLogin());

                for(User user:users)
                {
                    rep.addUser(user);
                }
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }


            if(req.getCode().equals("VIEW_BOOK")){
                Reply rep = new Reply();
                ArrayList<Book> books = getAllBooks();

                for(Book book : books){
                    rep.addBook(book);
                }

                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("ADD_BOOK"))
            {
                addBook(req.getBook());

                Reply rep = new Reply("ADDED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("ADD")){
                addUser(req.getUser());

                Reply rep = new Reply("ADDED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


            if(req.getCode().equals("ORDER")){
                Order(req.getBook());

                Reply reply = new Reply("ADDED SUCCESSFULLY");
                try {
                    oos.writeObject(reply);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


//            if(req.getCode().equals("SEARCH_BOOK")){
//                Reply reply = new Reply();
//                ArrayList<Book> books = getAllBooks();
//
//                for(Book book : books){
//                    reply.addBook(book);
//                }
//                try {
//                    oos.writeObject(reply);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }

            if(req.getCode().equals("EDIT_BOOK"))
            {
                updateBook(req.getBook());

                Reply rep = new Reply("EDITED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("VIEW_BLACKLIST"))
            {
                Reply rep = new Reply();
                ArrayList<Book> books = checkBlacklist();
                for(Book book : books)
                {
                    rep.addBook(book);
                }

                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            if(req.getCode().equals("ADD_READING_USER"))
            {
                addReadingUser(req.getUser(), req.getBook());
                Reply rep = new Reply("ADDED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            if(req.getCode().equals("REMOVE_BOOK")){
                removeBook(req.getId());
            }

            if(req.getCode().equals("BYE"))
                break;
        }
    }
}
