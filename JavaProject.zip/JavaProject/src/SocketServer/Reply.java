package SocketServer;

import MainClasses.User;

import java.io.Serializable;
import java.util.ArrayList;

public class Reply implements Serializable {
    private String code;
    private ArrayList<User> users = null;
    private ArrayList<Book> books = null;


    public Reply(String code) {
        this.code = code;
    }

    public Reply()
    {
        users = new ArrayList<>();
        books = new ArrayList<>();
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public ArrayList<Book> getBooks()
    {
        return books;
    }

    public Book getBook(int index){
        return books.get(index);
    }

    public int sizeBook(){
        return books.size();
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    public void setBooks(ArrayList<Book> books)
    {
        this.books = books;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void addUser(User user)
    {
        users.add(user);
    }

    public void addBook(Book book)
    {
        books.add(book);
    }
}
