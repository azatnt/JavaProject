package SocketServer;

import MainClasses.User;

import java.io.Serializable;
import java.util.ArrayList;

public class Request implements Serializable {
    private String code;
    private Book book;
    private int id;
    private User user;
    private String login;
    private ArrayList<User> users = null;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    public Request(){}

    public Request(String code, User user)
    {
        this.code = code;
        this.user = user;
    }

    public Request(String code, Book book) {
        this.code = code;
        this.book = book;
    }


    public Request(String code, int row){
        this.code = code;
        this.id = row;
    }

    public Request(String code, User user, Book book) {
        this.code = code;
        this.user = user;
        this.book = book;
    }

    public Request(String code, String login) {
        this.code = code;
        this.login = login;
    }


    public User getUser() {
        return user;
    }

    public Book getBook()
    {
        return book;
    }

    public Request(String code)
    {
        this.code = code;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setBook(Book book)
    {
        this.book = book;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    @Override
    public String toString() {
        return "Request{" +
                "code='" + code + '\'' +
                ", car=" + user +
                '}';
    }
}
