package sample;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import MainClasses.Controller;
import MainClasses.User;
import SocketServer.Book;
import SocketServer.Reply;
import SocketServer.Request;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import sample.animations.Cart;

public class Description {

    private ObservableList<Integer> timeChoice = FXCollections.observableArrayList(1, 2, 3, 4, 5);

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TextArea Description;

    @FXML
    private TextField NameField;

    @FXML
    private TextField AuthorField;

    @FXML
    private TextField ISBNField;

    @FXML
    private TextField PriceField;

    @FXML
    private Button Read;


    @FXML
    private ChoiceBox<Integer> TimeChoice;


    public void myFunc(Book book)
    {
        Description.setText(book.getDescription());
        NameField.setText(book.getName());
        AuthorField.setText(book.getAuthor());
        PriceField.setText(String.valueOf(book.getPrice()));
        ISBNField.setText(String.valueOf(book.getISBN()));
    }

    @FXML
    void initialize() {

        TimeChoice.setItems(timeChoice);

        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/View.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });


        Read.setOnAction(event -> {

            Controller controller = new Controller();
            String login = controller.getLogName();

            try {
                Socket socket = new Socket("127.0.0.1", 1999);
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

                String name = NameField.getText();
                int today = TimeChoice.getValue();

                Request request = new Request("GET_USER_BY_LOGIN", login);
                oos.writeObject(request);

                Reply request1 = (Reply)ois.readObject();
                ArrayList<User> list = request1.getUsers();



                Date date = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
                String currDate = formatter.format(date);
//                String testDate = formatter.format(date);
//                System.out.println(testDate);

                User user = new User(list.get(0).getName(), list.get(0).getSurname(), list.get(0).getLogin(), list.get(0).getPassword(), list.get(0).getAddress());
//                System.out.println(nameUser);
                Book book = new Book(name, today, currDate);

                Request req = new Request("ADD_READING_USER", user, book);
                oos.writeObject(req);

                Reply reply = (Reply)ois.readObject();
                System.out.println(reply.getCode());

                oos.close();
                ois.close();

                Alert dg = new Alert(Alert.AlertType.INFORMATION);
                dg.setTitle("Dear our costumer");
                dg.setContentText("Don't forget to return book on TIME!");
                dg.show();

            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });



    }
}
