package sample.animations;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import MainClasses.User;
import SocketServer.Book;
import SocketServer.Reply;
import SocketServer.Request;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class BlackList {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TableView<User> tableView;

    @FXML
    private TableColumn<User, Integer> IDColumn;

    @FXML
    private TableColumn<User, String> NameColumn;

    @FXML
    private TableColumn<User, String> LoginColumn;

    @FXML
    private TableColumn<User, String> AddressColumn;

    @FXML
    private TableColumn<Book, String> BookNameColumn;

    @FXML
    private TableColumn<User, Integer> FineColumn;

    @FXML
    private Button View;

    @FXML
    void initialize() {

        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Admin.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });


        try {
            Socket socket = new Socket("127.0.0.1", 1999);
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());


            Request request = new Request("VIEW_BLACKLIST");
            oos.writeObject(request);

            Reply reply = (Reply)ois.readObject();
            ArrayList<Book> list = reply.getBooks();
            ObservableList<Book> listBook = FXCollections.observableArrayList();
            for(Book book : list){
                listBook.addAll(book);
//                System.out.println(book);
                for(int i=0; i<listBook.size(); i++)
                {
                    int readingPeriod = listBook.get(i).getToday();
                    String startRead = listBook.get(i).getCurrDate();

//                    System.out.println(readingPeriod);
//                    System.out.println(startRead);

                    int total = readingPeriod + Integer.parseInt(startRead);
                    System.out.println(total);

//                    Date date = new Date();
//                    SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
//                    String currDate = formatter.format(date);
//
//
//                    if(total > Integer.parseInt(currDate))
//                    {
//                        System.out.println("BlackList");
//                    }
//                    else{
//                        System.out.println("Not Blacklist");
//                    }
                }






            }






        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        }

}

