package sample.animations;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import SocketServer.Book;
import SocketServer.Reply;
import SocketServer.Request;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.animations.Cart;

import javax.swing.*;

public class Buy {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TableView<Book> tableView;

    @FXML
    private TableColumn<Book, Integer> IDColumn;

    @FXML
    private TableColumn<Book, String> NameColumn;

    @FXML
    private TableColumn<Book, String> AuthorColumn;

    @FXML
    private TableColumn<Book, String> GenreColumn;

    @FXML
    private TableColumn<Book, Integer> ISBNColumn;

    @FXML
    private TableColumn<Book, Integer> AmountColumn;

    @FXML
    private TableColumn<Book, Integer> PriceColumn;

    @FXML
    private TableColumn<Book, Integer> RowColumn;

    @FXML
    private TableColumn<Book, Integer> ShelfColumn;

    @FXML
    private TextField SearchBox;

    @FXML
    private Button Buy;


    @FXML
    void Click(MouseEvent events) {
        Book book = tableView.getSelectionModel().getSelectedItem();
        if(book == null)
        {
            JOptionPane.showMessageDialog(null, "You didn't select");
        }
        else
        {
            Buy.setOnAction(event -> {
                Buy.getScene().getWindow().hide();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/FXMLfiles/Cart.fxml"));
                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Parent root = loader.getRoot();
                Cart cart = loader.getController();
                cart.buyFunc(book);
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.show();


//                Buy.setOnAction(event1 -> {
//                    FXMLLoader loader1 = new FXMLLoader();
//                    loader1.setLocation(getClass().getResource("/FXMLfiles/DescriptionBook.fxml"));
//                    try {
//                        loader1.load();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                    Parent root = loader1.getRoot();
//                    Cart cart = loader1.getController();
//                    cart.buyFunc(book);
//                    Stage stage = new Stage();
//                    stage.setScene(new Scene(root));
//                    stage.show();
//                });
            });

        }
    }

    @FXML
    void initialize() {
        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Consume.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });



        try {
            Socket socket = new Socket("127.0.0.1", 1999);
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());


            Request request = new Request("VIEW_BOOK");
            oos.writeObject(request);

            Reply reply = (Reply)ois.readObject();
            ArrayList<Book> list = reply.getBooks();
            ObservableList<Book> listBook = FXCollections.observableArrayList();
            for(Book book : list){
                listBook.addAll(book);
//                System.out.println(book);
            }
            IDColumn.setCellValueFactory(new PropertyValueFactory<Book, Integer>("id"));
            NameColumn.setCellValueFactory(new PropertyValueFactory<Book, String>("name"));
            AuthorColumn.setCellValueFactory(new PropertyValueFactory<Book, String>("author"));
            GenreColumn.setCellValueFactory(new PropertyValueFactory<Book, String>("genre"));
            ISBNColumn.setCellValueFactory(new PropertyValueFactory<Book, Integer>("ISBN"));
            AmountColumn.setCellValueFactory(new PropertyValueFactory<Book, Integer>("amount"));
            PriceColumn.setCellValueFactory(new PropertyValueFactory<Book, Integer>("price"));
            RowColumn.setCellValueFactory(new PropertyValueFactory<Book, Integer>("row"));
            ShelfColumn.setCellValueFactory(new PropertyValueFactory<Book, Integer>("shelf"));

            tableView.setItems(listBook);

            FilteredList<Book> filteredList = new FilteredList<>(listBook, book -> true);

            SearchBox.textProperty().addListener((observable, oldValue, newValue) -> {
                filteredList.setPredicate(book -> {


                    if (newValue == null || newValue.isEmpty())
                    {
                        return true;
                    }

                    String lowerCaseFilter = newValue.toLowerCase();

                    if(book.getName().toLowerCase().indexOf(lowerCaseFilter) != -1)
                    {
                        return true;
                    }
                    else if(book.getAuthor().toLowerCase().indexOf(lowerCaseFilter) != -1)
                    {
                        return true;
                    }
                    else if(book.getGenre().toLowerCase().indexOf(lowerCaseFilter) != -1)
                    {
                        return true;
                    }
                    else if(String.valueOf(book.getISBN()).indexOf(lowerCaseFilter) != -1)
                    {
                        return true;
                    }
                    else if(String.valueOf(book.getPrice()).indexOf(lowerCaseFilter) != -1)
                    {
                        return true;
                    }
                    else
                        return false;

                });
            });

            SortedList<Book> sortedList = new SortedList<>(filteredList);

            sortedList.comparatorProperty().bind(tableView.comparatorProperty());

            tableView.setItems(sortedList);




        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
