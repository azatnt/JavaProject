package sample.animations;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import SocketServer.Book;
import SocketServer.Reply;
import SocketServer.Request;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;

public class Cart {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Back;

    @FXML
    private TextArea CommentsField;

    @FXML
    private TextField NameField;

    @FXML
    private TextField PriceField;

    @FXML
    private TextField PhoneField;

    @FXML
    private TextField AddressField;

    @FXML
    private Button Buy;

    public void buyFunc(Book book)
    {
        NameField.setText(book.getName());
        PriceField.setText(String.valueOf(book.getPrice()));
    }

    @FXML
    void initialize() {

        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/View.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });


        Buy.setOnAction(event -> {
            try {
                Socket socket = new Socket("127.0.0.1", 1999);
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

                String name = NameField.getText();
                int price = Integer.parseInt(PriceField.getText());
                String address = AddressField.getText();
                String phone = PhoneField.getText();
                String comment = CommentsField.getText();

                Book book = new Book(name, price, address, phone, comment);

                Request req = new Request("ORDER", book);
                oos.writeObject(req);



                Reply rep = (Reply)ois.readObject();
                System.out.println(rep.getCode());


                oos.close();
                ois.close();

                Alert dg = new Alert(Alert.AlertType.INFORMATION);
                dg.setTitle("Dear our customer");
                dg.setContentText("Our manager will contact you!");
                dg.show();
//                JOptionPane.showMessageDialog(null, "Our manager will contact you!");

            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }


        });


    }
}
