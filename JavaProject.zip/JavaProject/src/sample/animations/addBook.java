package sample.animations;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import MainClasses.AdminMethods;
import SocketServer.Book;
import SocketServer.Reply;
import SocketServer.Request;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class addBook {

//    static AdminMethods adminMethods = new AdminMethods();
    private ObservableList<String>  genreChoices = FXCollections.observableArrayList("Action", "Adventure", "Art", "Biography", "Comic", "Crime", "Drama", "Fairytale",
            "Fantasy", "History", "Horror", "Novel", "Religion", "Romance", "Poetry", "Satire", "Thriller");
    private ObservableList<Integer> rowChoices = FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8);
    private ObservableList<Integer> shelfChoices = FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9);

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField Name;

    @FXML
    private TextField Author;

    @FXML
    private ChoiceBox<String> GenreChoiceBox;

    @FXML
    private TextField Amount;

    @FXML
    private TextField Price;

    @FXML
    private TextField ISBN;

    @FXML
    private ChoiceBox<Integer> RowChoiceBox;

    @FXML
    private ChoiceBox<Integer> ShelfChoiceBox;

    @FXML
    private Button Back;

    @FXML
    private Button Add;

    @FXML
    private TextArea DescriptionField;

    @FXML
    void initialize() {
        GenreChoiceBox.setItems(genreChoices);
        RowChoiceBox.setItems(rowChoices);
        ShelfChoiceBox.setItems(shelfChoices);

        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/Admin.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

        Add.setOnAction(event -> {
            try {
                Socket socket = new Socket("127.0.0.1", 1999);
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());


                String name = Name.getText();
                String author = Author.getText();
                int amount = Integer.parseInt(Amount.getText());
                int price = Integer.parseInt(Price.getText());
                int isbn = Integer.parseInt(ISBN.getText());
                String genre = GenreChoiceBox.getValue();
                int row = RowChoiceBox.getValue();
                int shelf = ShelfChoiceBox.getValue();
                String description = DescriptionField.getText();



                Book book = new Book(name, author, genre, isbn, amount, price, row, shelf, description);
                Request reqBook = new Request("ADD_BOOK", book);

                oos.writeObject(reqBook);

                Reply rep = (Reply)ois.readObject();
                System.out.println(rep.getCode());

                oos.close();
                ois.close();

               Alert dg = new Alert(Alert.AlertType.INFORMATION);
               dg.setTitle("Information for Admin");
               dg.setContentText("Book successfully added");
               dg.show();

            }  catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });


    }
}

