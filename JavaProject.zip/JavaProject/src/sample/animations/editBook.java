package sample.animations;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.GenericSignatureFormatError;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import SocketServer.Book;
import SocketServer.Reply;
import SocketServer.Request;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class editBook {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField Name;

    @FXML
    private TextField Author;

    @FXML
    private TextField Amount;

    @FXML
    private TextField Price;

    @FXML
    private TextField ISBN;

    @FXML
    private Button Back;

    @FXML
    private Button Edit;

    @FXML
    private TextArea DescriptionField;

    @FXML
    private TextField Genre;

    @FXML
    private TextField Row;

    @FXML
    private TextField Shelf;

    public void editFunc(Book book)
    {
        DescriptionField.setText(book.getDescription());
        Name.setText(book.getName());
        Author.setText(book.getAuthor());
        Genre.setText(book.getGenre());
        Amount.setText(String.valueOf(book.getAmount()));
        Price.setText(String.valueOf(book.getPrice()));
        ISBN.setText(String.valueOf(book.getISBN()));
        Row.setText(String.valueOf(book.getRow()));
        Shelf.setText(String.valueOf(book.getShelf()));
    }

    @FXML
    void initialize() {

        Back.setOnAction(event -> {
            Back.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/FXMLfiles/ViewBookAdmin.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });



        Edit.setOnAction(event -> {
            try {
                Socket socket = new Socket("127.0.0.1", 1999);
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());


                String name = Name.getText();
                String author = Author.getText();
                int amount = Integer.parseInt(Amount.getText());
                int price = Integer.parseInt(Price.getText());
                int isbn = Integer.parseInt(ISBN.getText());
                String genre = Genre.getText();
                int row = Integer.parseInt(Row.getText());
                int shelf = Integer.parseInt(Shelf.getText());
                String description = DescriptionField.getText();



                Book book = new Book (null, name, author, genre, isbn, amount, price, row, shelf, description);
                Request reqBook = new Request("EDIT_BOOK", book);

                oos.writeObject(reqBook);


                Reply rep = (Reply)ois.readObject();
                System.out.println(rep.getCode());

                oos.close();
                ois.close();

            }  catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });
    }
}
